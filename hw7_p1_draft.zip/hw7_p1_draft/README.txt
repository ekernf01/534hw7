This folder contains my solution to Stat 534 HW7 problem 1.

To compile: make

To run: ./cov_test

Output lies in erdata_samp_cov.txt (the true covariance) and synth_samp_cov.txt (the estimated covariance from 10,000 samples).

—Eric Kernfeld
